package utilities;

import net.thucydides.core.annotations.Step;

public class ReportMessege {
	
	 @Step
	 public void Info(String message){}

}
